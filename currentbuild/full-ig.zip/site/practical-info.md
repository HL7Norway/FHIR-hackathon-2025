# Practical Info - FHIR Hackathon 2025 v0.9.1

* [**Table of Contents**](toc.md)
* **Practical Info**

## Practical Info

This page contains practical info for presenters and participants.

The Norwegian FHIR Hackathon 2025 takes place on X-meeting point outside Oslo. You can get there by bus or car, or using the tube combined with a short bike ride/walk. The meeting takes place in room A2 in the meeting centre.

### Picture of the meeting room

![](rom-A5.png)

### Map of the meeting venue

 Room A2, where the Hackathon takes place is marked on this map. ![](motesenter.png)

### Refreshments

Snacks, water and coffe will be available for the participants in the "Catwalk" when you arrive. A two course lunch is served in the restaurant from 1200-1300. In addition coffee, water, tea, cookies and snacks is available for the afternoon break at 1430.

### Registration

You need to [register digitaly](https://hl7norway.github.io/FHIR-hackathon-2025/currentbuild/index.html#registration) to secure a place for attending the Hackathon. On the actual Hackathon you need to collect your participation badge from 0930. The Hackathon starts at 0930 so we plan to collect badges in the first break of the day.

