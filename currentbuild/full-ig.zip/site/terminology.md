# Terminology - FHIR Hackathon 2025 v1.1.0

* [**Table of Contents**](toc.md)
* **Terminology**

## Terminology

This page contains more detailed information about the Nordic tx FHIR server API and Terminology track.

