# Pre Agenda - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* **Pre Agenda**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

## Pre Agenda

* [Agenda for the pre meeting](#agenda-for-the-pre-meeting)
* [Virtual meeting invite](#virtual-meeting-invite)

### Agenda for the pre meeting

Proposed agenda for the hackathon pre meeting on the 3. november.
 **NOTE! The agenda is currently under active development and changes will occur without further notice.**

Date: 3. november 2025
 Time: 09:00-11:00
 [Virtual meeting](https://hl7norway.github.io/FHIR-hackathon-2025/currentbuild/pre-agenda.html#Virtual-meeting-invite)

#### Proposed agenda

The goal of the pre-meeting is to give a quick introduction to the different hackathon tracks, and make the participants capable of doing necessary preparations. The pre-meeting will be virtual only.

| | | |
| :--- | :--- | :--- |
| 0900 | Welcome | Thomas T Rosenlund |
| 0910 | PMD track intro | Michal |
| 0925 | OKT track intro | Robert |
| 0940 | Terminology track intro | Mattias |
| 0955 | IG track intro | Espen/Thomas |
| 1010 | Q&A and Discussion | All |
| 1100 | End of meeting | All |

### Virtual meeting invite

You will receive a Teams invitation to the virtual meeting when you sign up for the hackathon event.

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

