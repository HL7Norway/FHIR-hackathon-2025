# Pasient-1 - TTL Representation - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pasient-1**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

*  [Narrative Content](Patient-Pasient-1.md) 
*  [XML](Patient-Pasient-1.xml.md) 
*  [JSON](Patient-Pasient-1.json.md) 
*  [TTL](#) 

## : Pasient-1 - TTL Representation

[Raw ttl](Patient-Pasient-1.ttl) | [Download](Patient-Pasient-1.ttl)

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

