# Pasient - Examples - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pasient**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

*  [Content](StructureDefinition-mal-patient.md) 
*  [Detailed Descriptions](StructureDefinition-mal-patient-definitions.md) 
*  [Mappings](StructureDefinition-mal-patient-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-mal-patient.profile.xml.md) 
*  [JSON](StructureDefinition-mal-patient.profile.json.md) 
*  [TTL](StructureDefinition-mal-patient.profile.ttl.md) 

## Resource Profile: MalPatient - Examples

| |
| :--- |
| Draft as of 2025-01-22 |

Examples for the mal-patient Profile.

| |
| :--- |
| [Pasient-1](Patient-Pasient-1.md) |

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

