# Artifacts Summary - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

## Artifacts Summary

Contents:

*  [Structures: Resource Profiles](#1) 
*  [Example: Example Instances](#2) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Blodprøve](StructureDefinition-mal-observation-blodprove.md) | Profil for vanlige blodprøver |
| [Pasient](StructureDefinition-mal-patient.md) | Informasjon om pasienten, basert på no-basis. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Pasient-1](Patient-Pasient-1.md) | Eksempel på pasient med navn og fødselsnummer |

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

