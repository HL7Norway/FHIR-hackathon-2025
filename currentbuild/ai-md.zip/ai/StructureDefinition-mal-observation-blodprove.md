# Blodprøve - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Blodprøve**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-mal-observation-blodprove-definitions.md) 
*  [Mappings](StructureDefinition-mal-observation-blodprove-mappings.md) 
*  [XML](StructureDefinition-mal-observation-blodprove.profile.xml.md) 
*  [JSON](StructureDefinition-mal-observation-blodprove.profile.json.md) 
*  [TTL](StructureDefinition-mal-observation-blodprove.profile.ttl.md) 

## Resource Profile: Blodprøve 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/hackathon/2025/StructureDefinition/mal-observation-blodprove | *Version*:0.4.3 |
| Draft as of 2025-01-31 | *Computable Name*:MalObservationBlood |

 
Profil for vanlige blodprøver 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.hackathon.2025|current/StructureDefinition/mal-observation-blodprove)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Observation](http://hl7.org/fhir/R4/observation.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Observation](http://hl7.org/fhir/R4/observation.html) 

**Summary**

Must-Support: 3 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.effective[x]
* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Observation](http://hl7.org/fhir/R4/observation.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Observation](http://hl7.org/fhir/R4/observation.html) 

**Summary**

Must-Support: 3 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.effective[x]
* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-mal-observation-blodprove.csv), [Excel](StructureDefinition-mal-observation-blodprove.xlsx), [Schematron](StructureDefinition-mal-observation-blodprove.sch) 

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

