# Pasient - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pasient**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-mal-patient-definitions.md) 
*  [Mappings](StructureDefinition-mal-patient-mappings.md) 
*  [Examples](StructureDefinition-mal-patient-examples.md) 
*  [XML](StructureDefinition-mal-patient.profile.xml.md) 
*  [JSON](StructureDefinition-mal-patient.profile.json.md) 
*  [TTL](StructureDefinition-mal-patient.profile.ttl.md) 

## Resource Profile: Pasient 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/hackathon/2025/StructureDefinition/mal-patient | *Version*:0.4.3 |
| Draft as of 2025-01-22 | *Computable Name*:MalPatient |

 
Informasjon om pasienten, basert på no-basis. 

**Usages:**

* Examples for this Profile: [Patient/Pasient-1](Patient-Pasient-1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.no.hackathon.2025|current/StructureDefinition/mal-patient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [NoBasisPatient](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient) 

#### Terminology Bindings

#### Constraints

This structure is derived from [NoBasisPatient](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient) 

**Summary**

Must-Support: 2 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [NoBasisPatient](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [NoBasisPatient](https://simplifier.net/resolve?scope=hl7.fhir.no.basis@2.2.0&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Patient) 

**Summary**

Must-Support: 2 elements

 

Other representations of profile: [CSV](StructureDefinition-mal-patient.csv), [Excel](StructureDefinition-mal-patient.xlsx), [Schematron](StructureDefinition-mal-patient.sch) 

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

