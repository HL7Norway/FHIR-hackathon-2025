# Hack Agenda - FHIR Hackathon 2025 v0.4.3

* [**Table of Contents**](toc.md)
* **Hack Agenda**

FHIR Hackathon 2025 - Local Development build (v0.4.3) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

## Hack Agenda

### Agenda for the Hackathon

Proposed agenda for the hackathon 10. november.
 **NOTE! The agenda is currently under active development and changes will occur without further notice.**

| | | |
| :--- | :--- | :--- |
| 0930 | Welcome and Introductions (plenary) | Thomas T Rosenlund (Helsedirektoratet) og Nino Lo Cascio (Bedredelt) |
| 0945 | Intro to FHIR, IG and FHIR RESTful (plenary) | Thomas/Espen |
| 1015 | Parallell intros to tracks | Track leads |
| 1030 | Working in tracks | Track leads |
| 1200 | Lunch | NA |
| 1300 | Working in tracks | Track leads |
| 1430 | Coffee break | NA |
| 1445 | Working in tracks | Track leads |
| 1600 | Demo summary and discussions (plenary) | TBD + track leads |
| 1700 | End of day | All |

#### Parallell intros

Track introductions

* Intro to Pasientens måledata FHIR API interface (NHN)
* Intro to Oversikt over kommunale tjenester API (OKT API) and approaches for making FHIR API from existing services (Adam)
* Intro to terminology API and demo of nordic terminology server (Mattias?)
* Write and publish documentation of FHIR API's by publishing a FHIR IG (Thomas/Espen)

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.3 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

