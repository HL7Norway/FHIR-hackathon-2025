# Blodprøve - Definitions - FHIR Hackathon 2025 v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Blodprøve**

FHIR Hackathon 2025 - Local Development build (v0.4.2) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

*  [Content](StructureDefinition-mal-observation-blodprove.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-mal-observation-blodprove-mappings.md) 
*  [XML](StructureDefinition-mal-observation-blodprove.profile.xml.md) 
*  [JSON](StructureDefinition-mal-observation-blodprove.profile.json.md) 
*  [TTL](StructureDefinition-mal-observation-blodprove.profile.ttl.md) 

## Resource Profile: MalObservationBlood - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-01-31 |

Definitions for the mal-observation-blodprove resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

