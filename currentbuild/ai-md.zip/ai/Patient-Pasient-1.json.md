# Pasient-1 - JSON Representation - FHIR Hackathon 2025 v0.4.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pasient-1**

FHIR Hackathon 2025 - Local Development build (v0.4.2) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.no/fhir/ig/hackathon/2025/history.html)

*  [Narrative Content](Patient-Pasient-1.md) 
*  [XML](Patient-Pasient-1.xml.md) 
*  [JSON](#) 
*  [TTL](Patient-Pasient-1.ttl.md) 

## : Pasient-1 - JSON Representation

[Raw json](Patient-Pasient-1.json) | [Download](Patient-Pasient-1.json)

 IG © 2025+ [HL7 Norge](https://www.hl7.no). Package hl7.fhir.no.hackathon.2025#0.4.2 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

