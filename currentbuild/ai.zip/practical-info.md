# Practical Info - FHIR Hackathon 2025 v0.9.0

* [**Table of Contents**](toc.md)
* **Practical Info**

## Practical Info

This page contains practical info for presenters and participants.

FHIR Hackathon 2025 foregår på X-meeting point utenfor Oslo. Det er mulig å komme dit med buss eller bil, eventuelt sykkel og gange. Selve møtet foregår inne på møtesenteret i rom A2.

### Bilde av møterommet

![](rom-A5.png)

### Kart over møtesenteret

![](motesenter.png)

### Servering

Det vil være lett snacks, vann og kaffe tilgjengelig for deltakerne i "Catwalk" ved ankomst møtesenteret. Lunch serveres fra 1200 til 1300 i restauranten (to retters lunch). Det serveres i tillegg kaffe, kaker og snacks klokken 1430.

### Registrering

Registreringen er ikke åpen før 0930, så vi starter møtet før man registrerer seg for prekonferansen. Vi tar registreringen i første pause, dere får da også utdelt navnelapper som gir mulighet for å få lunch.

