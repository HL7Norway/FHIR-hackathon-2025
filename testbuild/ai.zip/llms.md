# hl7.fhir.no.hackathon.2025#1.4.5: FHIR Hackathon 2025

## Pages

* [Home](index.md)
* [Track Descriptions](track-descriptions.md)
* [Terminology](terminology.md)
* [Hack Agenda](hack-agenda.md)
* [Resultater Bilder](resultater-bilder.md)
* [Resultater Pmd](resultater-pmd.md)
* [Resultater Okt](resultater-okt.md)
* [2026 Changes](2026-changes.md)
* [Pre Agenda](pre-agenda.md)
* [Artifacts Summary](artifacts.md)
* [Ig Publishing](ig-publishing.md)
* [Practical Info](practical-info.md)
* [Ig Publishing Results](ig-publishing-results.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [FHIR Hackathon 2025](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
