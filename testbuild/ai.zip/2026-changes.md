# 2026 Changes - FHIR Hackathon 2025 v1.4.1

* [**Table of Contents**](toc.md)
* **2026 Changes**

## 2026 Changes

### Proposed changes

Get more clinicians on the hackathon to provide feedback and co-devlop API's and software solutions.

### Value proposal (use-case)

Why should clinicians care and participate?

### Method

Method for user involvement in software development.

