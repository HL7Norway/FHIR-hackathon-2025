# Resultater Okt - FHIR Hackathon 2025 v1.4.3

* [**Table of Contents**](toc.md)
* **Resultater Okt**

## Resultater Okt

Summary of the results from OKT-track

Detailed results are discussed in the [OKT IG repo](https://hl7norway.github.io/FHIR-hackathon-2025-okt-ig/currentbuild/).

### High level summary

* 10 participants
* Det er alltid mindre tid enn det man har tenkt, mye å diskutere
* Tre ressurser som kan uttrykke det som tilbys gjennom OKT-API
* ServiceReqest, CarePlan eller Episode of Care for OKT

#### EpisodeOfCare - hvilke felter som er implementert i pilot

* Eksempler i en IG, identifisert noen endringer
* Datafelt trengs ikke i modellen
* Testet og forbedrert EpisodeofCare profilen

